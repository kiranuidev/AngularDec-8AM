// Code goes here

(function() {

    angular.module("isolatedScopeDemo", [])
      .controller("userCtrl", ["$scope", userCtrl])
      .controller("productCtrl", ["$scope", productCtrl])
      .directive("dirUser", [dirUser])


    function userCtrl($scope) {
      $scope.username = "Kiran";
      $scope.myproperty="I am Interested on this";
      var vm = this;
      vm.checkname = "test";
      
    }

    function productCtrl($scope) {
      $scope.productName = "I am the product";
      $scope.anything = " iam anything";

    }

    function dirUser() {
      return {
        template: "<button ng-click='change()'>Click</button><h1>Directive: {{myname}}</h1><h1>two way:{{changeprop}}<h1>",
        restrict: "E",
        scope: {
          myname: "@",
          myid: "@",
          changeprop: "="
        },

        link: function(scope, element, attrs) {
          scope.change = function() {
            scope.myname = "Paturi";
            scope.changeprop="Hey I am chaging you";
          }
        }
      }
    }

  }














)();